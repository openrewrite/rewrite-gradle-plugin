# Reproduction: UpdateGradleWrapper reads from disk, not git

This project demonstrates that `org.openrewrite.gradle.UpdateGradleWrapper` reads
from the filesystem working directory, **not** from the git committed state.

## Current state

- **Git HEAD commit**: Gradle wrapper set to **8.14.4**
- **Working directory (on disk)**: Gradle wrapper set to **8.14.3** (uncommitted)
- The rewrite plugin (`org.openrewrite.rewrite` version `7.28.1`) is configured to
  run `UpdateGradleWrapper` with `version: "8.x"`

## Run the recipe

```bash
./gradlew rewriteRun
```

## Expected result

The recipe detects that the **on-disk** version is `8.14.3` (not the latest `8.x`)
and upgrades it to `8.14.4`. This proves the plugin reads from the working
directory, not from the git committed state.

## Verify

After running, check that the wrapper was upgraded:

```bash
grep distributionUrl gradle/wrapper/gradle-wrapper.properties
```

You should see `gradle-8.14.4` in the URL.

## Note

If your default Java version is too new (e.g., Java 25), you may need to point
to a compatible JDK:

```bash
JAVA_HOME=/path/to/jdk17 ./gradlew rewriteRun
```
